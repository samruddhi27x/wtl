<?php
if($_GET['username'] || $_GET['password']){
    echo "UserName : ".$_GET['username'];
    echo "Password : ".$_GET['password'];
}
?>
